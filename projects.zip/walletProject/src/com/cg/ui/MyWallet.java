package com.cg.ui;

import com.cg.Exception.InsufficientFundException;
import com.cg.bean.*;
import com.cg.service.AccountService;
import com.cg.service.Gst;

public class MyWallet {

		public static void main(String [] args) {
			
			AccountService service = new AccountService();
			SavingAccount ob = new SavingAccount(100, "9998969592","name again", 56000);
			
			service.printStatement(ob);
			double b = 0;
			
			try {
				b = service.withdraw(ob, 55010);
				System.out.println("After withdrawal balance is " + b);
			}
			catch(InsufficientFundException e) {
				e.printStackTrace();
			}
			
			
			double tax = service.calculateTax(Gst.PCT_5, b);
			System.out.println("GST is " + tax);
			
			
			
		}
}
