package com.cg;

import java.util.*;
import com.cg.bean.*;

public class Demo7 {

	public static void main(String[] args) {
		
		Map<String, Account> accMap = new TreeMap<String, Account>();
		Account ob1 = new Account(101,"9996958778", "ram", 25000);
		accMap.put(ob1.getPhone(), ob1);

		
		Account ob2 = new Account(102,"9996958898", "shyam", 55000);
		accMap.put(ob2.getPhone(), ob2);

		
		Account ob3 = new Account(104,"9996978778", "kaam", 15000);
		accMap.put(ob3.getPhone(), ob3);

		
		Account ob4 = new Account(103,"9989958778", "abdul", 45000);
		accMap.put(ob4.getPhone(), ob4);

		
		System.out.println(accMap);
		System.out.println();

		System.out.println(accMap.keySet());
		
		Collection<Account> vals = accMap.values();
		List<Account> accList = new ArrayList<Account>(vals);
		Collections.sort(accList);     //sort by id
		
		for(Account a: accList)
			System.out.println(a);
		System.out.println();

		
		//sort by name
		Comparator nc = new NameComparator();
		Collections.sort(accList, nc);
		for(Account a: accList)
			System.out.println(a);
		System.out.println();

		
		//sort by balance
		Comparator bc = new BalanceComparator();
		Collections.sort(accList, bc);
		for(Account a: accList)
			System.out.println(a);
	}

}
