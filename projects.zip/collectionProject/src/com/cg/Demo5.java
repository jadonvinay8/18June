package com.cg;

import java.util.*;

public class Demo5 {

	public static void main(String[] args) {
		// null is allowed. duplicates are also allowed. list is ordered.
		
		List<String> set = new ArrayList<String>();
		
		set.add("ram");
		set.add("sham");
		set.add("abdul");
	  //set.add(55);
		set.add(null);
		set.add("ganesh");
		set.add("ram");
		System.out.println(set);
		System.out.println(set.size());
		
		for(String s: set)
			System.out.println(s);
		
		Iterator<String> it = set.iterator();
		while(it.hasNext()) {
			String ss = it.next();
			System.out.println(ss);
			
		}
	}

}
