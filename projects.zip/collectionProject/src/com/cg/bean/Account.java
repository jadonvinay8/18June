package com.cg.bean;

public class Account implements Comparable<Account> {
	
	private int aid;
	private String phone;
	private String accountHolder;
	private double balance;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(int aid, String phone, String accountHolder, double balance) {
		super();
		this.aid = aid;
		this.phone = phone;
		this.accountHolder = accountHolder;
		this.balance = balance;
	}

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [aid=" + aid + ", phone=" + phone + ", accountHolder=" + accountHolder + ", balance=" + balance
				+ "]";
	}

	@Override
	public int compareTo(Account a) {
		// sorting on the basis of account number
		
		int difference = this.getAid() - a.getAid();
		
		if(difference > 0)
			return 1;
		else if(difference < 0)
			return -1;
		else
			return 0;
	}
	
	/*public double withdraw(double amount) {
		balance -= amount;
		return balance;
	}
	*/
}
