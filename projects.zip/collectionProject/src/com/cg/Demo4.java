package com.cg;

import java.util.*;

public class Demo4 {
	
	public static void main(String[] args) {
		// Tree does not permit null as object. throws NullPointerException
		// sorted alphabetically and hence unordered
		// in case of hashTree, keys are sorted
		
		Set<String> set = new TreeSet<String>();
		
		set.add("ram");
		set.add("sham");
		set.add("abdul");
	  //set.add(55);
	  //set.add(null);
		set.add("ganesh");
		set.add("ram");
		System.out.println(set);
		System.out.println(set.size());
	}
}
