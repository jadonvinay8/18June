package com.cg;

import java.util.HashSet;
import java.util.Set;

public class Demo2 {

	public static void main(String[] args) {
		// generic collection
		
		Set<String> set = new HashSet<String>();
		
		set.add("ram");
		set.add("sham");
		set.add("abdul");
	  //set.add(55);
		set.add(null);
		set.add("ganesh");
		set.add("ram");
		System.out.println(set);
		System.out.println(set.size());

	}

}
